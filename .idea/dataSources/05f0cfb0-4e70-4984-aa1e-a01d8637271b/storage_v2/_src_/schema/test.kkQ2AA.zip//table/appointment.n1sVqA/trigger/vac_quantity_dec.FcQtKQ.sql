create definer = root@localhost trigger vac_quantity_dec
    after insert
    on appointment
    for each row
BEGIN
    UPDATE vaccines
    SET quantity = quantity - 1
    WHERE id = NEW.vaccine_id;
END;

