create definer = root@localhost view appointment_view as
select `a`.`id`                                   AS `id`,
       `a`.`user_id`                              AS `user_id`,
       coalesce(`r`.`firstname`, `u`.`firstname`) AS `patient_name`,
       coalesce(`r`.`lastname`, `u`.`lastname`)   AS `patient_lastname`,
       `vc`.`name`                                AS `vaccination_center_name`,
       `ts`.`start_time`                          AS `timeslot_start_time`,
       `ts`.`end_time`                            AS `timeslot_end_time`,
       `v`.`name`                                 AS `vaccine_name`,
       `a`.`booking_date`                         AS `booking_date`
from (((((`test`.`appointment` `a` left join `test`.`users` `u`
          on ((`a`.`user_id` = `u`.`id`))) left join `test`.`relatives` `r`
         on ((`a`.`relative_id` = `r`.`id`))) left join `test`.`vaccinationcenter` `vc`
        on ((`a`.`center_id` = `vc`.`id`))) left join `test`.`timeslots` `ts`
       on ((`a`.`timeslot_id` = `ts`.`id`))) left join `test`.`vaccines` `v` on ((`a`.`vaccine_id` = `v`.`id`)));

